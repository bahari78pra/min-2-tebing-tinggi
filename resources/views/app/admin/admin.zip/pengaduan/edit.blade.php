@extends("layouts.app")

@section("content")
<h4 class="c-grey-900 mT-10 mB-10">Edit Pengaduan</h4>
<div>
    <form action="{{ route('admin.pengaduan.update') }}" method="POST" class='row' enctype="multipart/form-data">
        {{ csrf_field() }} 
        {{ method_field('PUT') }}
        <div class="col-md-12 col-lg-8">
            <div class="bgc-white bd bdrs-3 p-20 mB-20">
                <h6>Data Pengaduan</h6>
                @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <input type="hidden" name="id" value="{{ $pengaduan->id }}">

                <div class="form-row">
                    <div class="form-group col-sm-12">
                        <label for="nama">Nama <sup style='color:red'>*</sup></label>
                        <input type="text" name="nama" id="nama" class='form-control' required value="{{ old('nama', $pengaduan->nama) }}">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group col-sm-12">
                        <label for="email">Email <sup style='color:red'>*</sup></label>
                        <input type="text" name="email" id="email" class='form-control' required value="{{ old('email', $pengaduan->email) }}">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group col-sm-12">
                        <label for="judul_pengaduan">Judul <sup style='color:red'>*</sup></label>
                        <input type="text" name="judul_pengaduan" id="judul_pengaduan" class='form-control' required value="{{ old('judul_pengaduan', $pengaduan->judul_pengaduan) }}">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group col-sm-12">
                        <label for="isi_pengaduan">Isi Pengadauan <sup style='color:red'>*</sup></label>
                        <textarea class="form-control" id="editor" name="isi_pengaduan" rows="30" required>
                            {{ $pengaduan->isi_pengaduan }}
                        </textarea>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-lg-4">
            <div class="bgc-white bd bdrs-3 p-20 mB-20">
                <h6>Aksi</h6>
                <p>Simpan data pengaduan.</p>
                <button type="submit" class='btn btn-success'>Simpan</button>
                <a href="{{ route('admin.pengaduan') }}" class='btn btn-danger'>Batal</a>
            </div>
        </div>
        <div class="clearfix"></div>
    </form>
</div>
@endsection
