@extends('layouts.app')

<!-- SECTION FOR TITLE CONTENT -->
@section('title', 'Pengaduan Online')

<!-- SECTION FOR CONTENT -->
@section('content')

<h4 class="c-grey-900 mT-10 mB-30">Pengaduan Online</h4>
@if(Session::has('flash_message'))
    <script type="text/javascript">
        swal("Berhasil!", "Data berhasil disimpan!", "success");
    </script>
@endif
<div class="row">
    <div class="col-md-12">
        <div class="bgc-white bd bdrs-3 p-20 mB-20">
            <div class="row">
                <div class="col-md-6">
                    <a href="{{ route('admin.pengaduan.create') }}" class="btn btn-primary mB-30">Tambah Pengaduan</a>
                </div>
                <div class="col-md-6">
                    <form action="#" method="GET" style='display:flex' class='mB-20'>
                        <input type="text" name="q_nama" placeholder="Nama" class='form-control' value="{{ $key_nama }}">
                        <input type="text" name="q" placeholder="Judul Pengaduan" class='form-control' value="{{ $keywords }}" style="margin-left: 10px;">
                        <button type="submit" class='btn btn-primary mL-10'>Cari</button>
                    </form>
                </div>
            </div>
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th width="10%">#</th>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>Judul</th>
                        <th width="10%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @if(count($pengaduan) == 0)
                        <tr>
                            <td colspan="6" class="text-left">
                                @if($keywords == "")
                                <i>Tidak ada data!</i>
                                @else
                                <i>Data tidak ditemukan!</i>
                                @endif
                            </td>
                        </tr>
                    @endif
                    @foreach($pengaduan as $pengaduan_data)
                        <tr>
                            <td>{{ $loop->iteration + $skipped }}</td>
                            <td>{{ $pengaduan_data->nama }}</td>
                            <td>{{ $pengaduan_data->email }}</td>
                            <td>{{ $pengaduan_data->judul_pengaduan }}</td>
                            <td>
                                <a href="{{ route('admin.pengaduan.edit',$pengaduan_data->id) }}" title="Edit"><button class="btn btn-warning"><span class="fa fa-pencil"></span></button></a>
                                <form onsubmit="deleteThis(event)" action="{{ route('admin.pengaduan.delete') }}" class="delete" method="post" style="display: inline;">
                                    {{ csrf_field() }} 
                                    {{ method_field('DELETE') }}
                                    <input type="hidden" class="form-control" name="id" value="{{ $pengaduan_data->id }}">
                                    <button class="btn btn-danger" type="submit"><i class="fa fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>

            <div style="justify-content: center;display: flex;">
                {{ $pengaduan->appends(['q' => $keywords])->links() }}
            </div>
        </div>
    </div>
</div>
@endsection

@section('footer-scripts')
<script type="text/javascript">
    function deleteThis(e){
        e.preventDefault();
        swal({
          title: "Apakah anda yakin?",
          text: "Data akan dihapus secara permanen!",
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
        .then((willDelete) => {
          if (willDelete) {
            e.target.submit();
            swal("Data telah dihapus!", {
              icon: "success",
            });
          }
        });
        return false;
    }
</script>
@endsection