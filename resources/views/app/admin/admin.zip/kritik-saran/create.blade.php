@extends("layouts.app")

@section("content")
<h4 class="c-grey-900 mT-10 mB-10">Tambah Kritik/Saran</h4>
<div>
    <form action="{{ route('admin.kritik_saran.insert') }}" method="POST" class='row' enctype="multipart/form-data">
        {{ csrf_field() }} 
        {{ method_field('POST') }}
        <div class="col-md-12 col-lg-8">
            <div class="bgc-white bd bdrs-3 p-20 mB-20">
                <h6>Data Kritik/Saran</h6>
                @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <div class="form-row">
                    <div class="form-group col-sm-12">
                        <label for="nama">Nama <sup style='color:red'>*</sup></label>
                        <input type="text" name="nama" id="nama" class='form-control' required value="{{ old('nama') }}">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group col-sm-12">
                        <label for="email">Email <sup style='color:red'>*</sup></label>
                        <input type="text" name="email" id="email" class='form-control' required value="{{ old('email') }}">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group col-sm-12">
                        <label for="judul_kritik">Judul <sup style='color:red'>*</sup></label>
                        <input type="text" name="judul_kritik" id="judul_kritik" class='form-control' required value="{{ old('judul_kritik') }}">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group col-sm-12">
                        <label for="isi_kritik">Isi Pengadauan <sup style='color:red'>*</sup></label>
                        <textarea class="form-control" id="editor" name="isi_kritik" rows="30" required></textarea>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-lg-4">
            <div class="bgc-white bd bdrs-3 p-20 mB-20">
                <h6>Aksi</h6>
                <p>Simpan data kritik/saran.</p>
                <button type="submit" class='btn btn-success'>Simpan</button>
                <a href="{{ route('admin.kritik_saran') }}" class='btn btn-danger'>Batal</a>
            </div>
        </div>
        <div class="clearfix"></div>
    </form>
</div>
@endsection
